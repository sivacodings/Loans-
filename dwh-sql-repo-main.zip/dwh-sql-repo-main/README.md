# dwh-sql-repo
All common code that i am going to share to our aspirants
